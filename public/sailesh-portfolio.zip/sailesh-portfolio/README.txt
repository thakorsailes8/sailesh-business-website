========================================================================
SAILESH DESIGNS STUDIO - COMPLETE WEBSITE PACKAGE
========================================================================
Owner: Sailesh (thakorsailes8@gmail.com)

FOLDER STRUCTURE:
- index.html        (Home Page - Double click to open)
- about.html        (About Me Page)
- services.html     (Services Page)
- gallery.html      (Portfolio Gallery Page)
- contact.html      (Contact Page)
- images/           (All image files - drop your photos here)
- react-project/    (React + Vite + Tailwind source code)
- PHOTO-GUIDE-HINDI.txt (Hindi instructions for adding photos)

Double click "index.html" to run the website instantly in any browser!
========================================================================
