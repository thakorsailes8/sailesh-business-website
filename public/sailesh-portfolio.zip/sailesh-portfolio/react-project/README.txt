========================================================================
SAILESH DESIGNS - REACT VERSION
========================================================================
To run the React version:
1. Open this folder in terminal / command prompt:
   cd react-project
2. Run:
   npm install
   npm run dev
3. Open http://localhost:3000 in your browser.
