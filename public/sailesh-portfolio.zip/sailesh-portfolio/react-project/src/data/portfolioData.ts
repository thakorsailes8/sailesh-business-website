export interface ProjectItem {
  id: string;
  title: string;
  subtitle: string;
  category: 'uiux' | 'websites' | 'social' | 'ai-video' | 'resumes';
  categoryLabel: string;
  tag: string;
  tools: string;
  client: string;
  year: string;
  image: string;
  description: string;
  challenge?: string;
  solution?: string;
  deliverables?: string[];
  metrics?: string;
  isSpotlight?: boolean;
}

export interface ServiceItem {
  id: string;
  number: string;
  code: string;
  title: string;
  icon: string;
  tagline: string;
  description: string;
  image: string;
  deliverables: string[];
  highlight: string;
}

// =========================================================================
// IMAGES GUIDE: Add your image URLs or local paths here (e.g. image: '/assets/apex.jpg')
// All images have <img> tags pre-configured across the website components!
// =========================================================================
export const PORTFOLIO_PROJECTS: ProjectItem[] = [
  {
    id: 'apex-fintech',
    title: 'Apex Fintech — Web Application & Brand Redesign',
    subtitle: 'High-frequency liquidity trading interface & design system',
    category: 'uiux',
    categoryLabel: 'UI/UX Design',
    tag: 'Case Study • Spotlight',
    tools: 'Figma • React • Tailwind • Tokens',
    client: 'Apex Global Markets',
    year: '2024–2025',
    image: '',
    description: 'Complete overhaul of high-frequency liquidity trading interface into an approachable modular workspace. Reduced customer cognitive overload by 42% through structured information hierarchy and design token consolidation.',
    challenge: 'Traders faced severe interface density overload, fragmented styling across desktop modules, and slow chart configuration times.',
    solution: 'Designed an ergonomic modular layout with custom dark mode palettes, standardized typography tokens, real-time telemetry pill indicators, and one-click order execution flows.',
    deliverables: ['Design System Tokens', 'Modular Dashboard Layout', 'Dark & Light Mode Variants', 'Interactive Clickable Prototype', 'Component Library Documentation'],
    metrics: '-42% Cognitive Overload, 99.8% System Uptime Score',
    isSpotlight: true,
  },
  {
    id: 'nova-health',
    title: 'Nova Health Portal',
    subtitle: 'Telemedicine patient portal & appointment telemetry',
    category: 'uiux',
    categoryLabel: 'UI/UX Design',
    tag: 'Web App',
    tools: 'Figma • React',
    client: 'Nova Health Inc.',
    year: '2024',
    image: '',
    description: 'Clean telemedicine patient portal and remote appointment dashboard engineered for swift clinical access, patient records, and vitals telemetry tracking.',
    challenge: 'Patients struggled with cluttered scheduling screens and inconsistent prescription statuses across disparate clinic databases.',
    solution: 'Structured a calm, accessible health dashboard using soft purple and teal feedback accents, streamlined appointment booking in 3 steps, and integrated instant doctor chat.',
    deliverables: ['Patient Portal UX', 'Doctor Schedule Calendar', 'Vitals Telemetry Cards', 'Mobile Adaptive Views'],
    metrics: '3.4x Faster Appointment Booking',
  },
  {
    id: 'luxe-horizon',
    title: 'Luxe Horizon Apparel',
    subtitle: 'Luxury minimalist fashion e-commerce storefront',
    category: 'websites',
    categoryLabel: 'Websites',
    tag: 'E-Commerce',
    tools: 'Shopify • Next.js',
    client: 'Luxe Horizon Paris',
    year: '2024',
    image: '',
    description: 'Modern luxury e-commerce landing page with sleek editorial typography, micro-interactions, curated lookbooks, and high conversion checkout flow.',
    challenge: 'High bounce rate on previous storefront due to sluggish load times and generic template visual hierarchy.',
    solution: 'Implemented headless architecture with Next.js, bespoke editorial serif pairings, micro-interactions for garment reveals, and optimized cart drawers.',
    deliverables: ['Headless Storefront Frontend', 'Lookbook Collection Grid', 'Responsive Product Detail Page', 'Checkout UX Optimizations'],
    metrics: '+68% Mobile Conversion Rate, 98+ PageSpeed Score',
  },
  {
    id: 'cyberpulse-ai',
    title: 'CyberPulse AI Series',
    subtitle: 'Futuristic AI product launch social carousel & banners',
    category: 'social',
    categoryLabel: 'Social Media Posts',
    tag: 'Campaign',
    tools: 'Photoshop • Illustrator',
    client: 'CyberPulse Tech',
    year: '2024',
    image: '',
    description: 'High-conversion Instagram carousel designs and multi-format tech promo banners for a cutting-edge AI product rollout campaign.',
    challenge: 'Explaining intricate deep-learning models in bite-sized visual slides without boring tech audiences or diluting brand sophistication.',
    solution: 'Created an 8-slide sequential carousel framework featuring holographic asset styling, high-contrast infographics, and compelling hook headlines.',
    deliverables: ['8-Slide Instagram Carousel', 'LinkedIn Banner Suite', 'Story Ads (9:16)', 'Reusable Figma Component Template'],
    metrics: '4.8x Higher Viral Saves & Shares',
  },
  {
    id: 'synthetica-teaser',
    title: 'Synthetica Brand Teaser',
    subtitle: 'Generative AI motion reel and brand teaser snippet',
    category: 'ai-video',
    categoryLabel: 'AI Videos',
    tag: '00:45 Reel',
    tools: 'Runway • Premiere Pro',
    client: 'Synthetica Labs',
    year: '2025',
    image: '',
    description: 'AI-generated cinematic promotional reel and motion graphic snippet highlighting generative creative capabilities with particle physics and chromatic violet tones.',
    challenge: 'Producing an agency-grade commercial promo video within 48 hours without expensive live studio filming.',
    solution: 'Leveraged generative AI diffusion models for hyper-detailed textures, sculpted particle motion in 3D, and synchronized precise audio beat drops in Premiere.',
    deliverables: ['Full 45-Second Brand Reel', 'Social Teaser Cutdowns (15s & 30s)', 'Custom Soundscape & Audio Mix', 'Keyframe Asset Library'],
    metrics: '250K+ Organic Video Impressions in 7 Days',
  },
  {
    id: 'nextgen-saas',
    title: 'NextGen SaaS Platform',
    subtitle: 'B2B Analytics workspace with interactive charts',
    category: 'uiux',
    categoryLabel: 'UI/UX Design',
    tag: 'SaaS Product',
    tools: 'Tailwind • Vue',
    client: 'NextGen Cloud',
    year: '2024',
    image: '',
    description: 'Analytics dashboard with sleek spline charts, dark mode accents, responsive modules, and intuitive card components for enterprise product managers.',
    challenge: 'Data fragmentation across multiple third-party analytics connectors causing slow team decisions.',
    solution: 'Architected unified metric cards with quick filtering, customizable widget dashboards, and low-latency interactive graph tooltips.',
    deliverables: ['Dashboard UI Components', 'Chart Visualizations', 'Custom Icon Set', 'Exportable PDF Report Template'],
    metrics: '+85% Daily Active Usage by Product Teams',
  },
  {
    id: 'velocity-fitness',
    title: 'Velocity Fitness Brand',
    subtitle: 'High-energy sportswear campaign graphics & social assets',
    category: 'social',
    categoryLabel: 'Social Media Posts',
    tag: 'Brand Identity',
    tools: 'Brand Identity • Figma',
    client: 'Velocity Activewear',
    year: '2024',
    image: '',
    description: 'Vibrant fitness apparel campaign graphics, promotional social banners, and dynamic vertical stories engineered to maximize flash-sale CTR.',
    challenge: 'Needed a striking summer collection launch campaign that stood out in crowded fitness feeds.',
    solution: 'Combined energetic neon violet movement trails, bold condensed athletic typography, and instant promotion badge highlights.',
    deliverables: ['12 Promotional Banner Formats', 'Instagram Story Templates', 'Email Marketing Header Graphics', 'Brand Color & Typography Guide'],
    metrics: '2.9x Return on Ad Spend (ROAS)',
  },
  {
    id: 'executive-cv',
    title: 'Executive Tech Leader CV',
    subtitle: 'ATS-compliant visual resume & executive career portfolio',
    category: 'resumes',
    categoryLabel: 'Resume Designs',
    tag: 'Executive ATS',
    tools: 'Print & Digital PDF',
    client: 'Chief Technology Officer Candidate',
    year: '2024',
    image: '',
    description: 'Minimalist ATS-compliant visual executive resume and personalized digital presentation portfolio deck highlighting technical leadership and scaled exits.',
    challenge: 'A seasoned engineering executive needed a resume that passed corporate ATS algorithms while immediately impressing executive search committees visually.',
    solution: 'Constructed an dual-layer architecture: rigorous ATS semantic text scanning flow paired with Swiss typographic hierarchy, clean timeline milestones, and metric capsules.',
    deliverables: ['ATS-Optimized Single & Two-Page CV', 'Executive Career Deck (PDF)', 'Personal Domain Portfolio Layout', 'LinkedIn Profile Overhaul Kit'],
    metrics: 'Invited to 5 Tier-1 Tech Leadership Interviews',
  },
  {
    id: 'zenith-cloud',
    title: 'Zenith Cloud Architecture',
    subtitle: 'Enterprise B2B SaaS landing page & technical docs',
    category: 'websites',
    categoryLabel: 'Websites',
    tag: 'B2B SaaS',
    tools: 'Webflow • HTML5',
    client: 'Zenith Systems',
    year: '2024',
    image: '',
    description: 'High-converting B2B SaaS landing page built with clean responsive components, live stats, interactive architecture diagrams, and technical documentation.',
    challenge: 'Complex infrastructure product had a high drop-off rate on pricing and feature documentation pages.',
    solution: 'Designed intuitive interactive architecture explorer cards, streamlined tier comparison tables, and frictionless trial registration.',
    deliverables: ['High-Performance Conversion Landing Page', 'Interactive Architecture Calculator', 'Technical Documentation Layout', 'Responsive Mobile Testing'],
    metrics: '+41% Enterprise Demo Bookings',
  },
];

export const SERVICES_LIST: ServiceItem[] = [
  {
    id: 'uiux-design',
    number: '01',
    code: '01 // UI-UX',
    title: 'UI/UX Design',
    icon: 'devices_fold',
    tagline: 'Intuitive, user-centered digital product interfaces designed for clarity, usability, and effortless adoption.',
    description: 'Clean wireframing, high-fidelity prototypes, user research, and modern intuitive design systems tailored for seamless product interactions.',
    image: '',
    deliverables: [
      'User journey mapping & flows',
      'Wireframing & UX prototypes',
      'Interactive Figma prototypes',
      'Scalable design systems & tokens',
      'Mobile & desktop adaptive layouts',
    ],
    highlight: 'Human-centric wireframing and component tokens built for scale.',
  },
  {
    id: 'web-dev',
    number: '02',
    code: '02 // WEB-DEV',
    title: 'Website Design & Development',
    icon: 'code',
    tagline: 'Responsive, lightning-fast modern websites built with semantic HTML5, CSS3, modern JavaScript, and Bootstrap 5.',
    description: 'Responsive, clean-coded websites built with HTML5, CSS3, modern JavaScript, and Bootstrap 5 engineered for speed, SEO, and device adaptation.',
    image: '',
    deliverables: [
      'Custom landing pages & portfolios',
      'Mobile-first responsive architecture',
      'Modern JS & Bootstrap 5 integration',
      'Cross-browser speed optimization',
      'Clean documentation & source handoff',
    ],
    highlight: 'Semantic HTML5, CSS Grid/Flexbox, Tailwind CSS & Bootstrap 5.',
  },
  {
    id: 'social-media',
    number: '03',
    code: '03 // SOCIAL',
    title: 'Social Media & Marketing Posts',
    icon: 'auto_awesome_motion',
    tagline: 'Visually magnetic promotional graphics that stop the scroll, strengthen brand authority, and boost engagement.',
    description: 'Eye-catching marketing creatives, carousel decks, branded banners, and AI-assisted visual art calibrated for maximum feed engagement.',
    image: '',
    deliverables: [
      'Instagram multi-slide carousels',
      'LinkedIn banner sets & executive assets',
      'High-conversion ad creative suites',
      'Custom reusable Figma / Canva templates',
      'Product promotional campaign packs',
    ],
    highlight: 'Brand narrative systems, typography pairing, and scroll-stopping visuals.',
  },
  {
    id: 'ai-video',
    number: '04',
    code: '04 // AI-VIDEO',
    title: 'AI Video & Reels Creation',
    icon: 'movie_filter',
    tagline: 'High-impact short-form video content and AI-assisted dynamic reels crafted for Instagram, TikTok, and YouTube Shorts.',
    description: 'High-engagement short-form videos, promotional motion clips, and viral social media reels that tell compelling brand stories dynamically.',
    image: '',
    deliverables: [
      'Dynamic narrative scripting & hooks',
      'AI visual generation & smart avatars',
      'Kinetic motion subtitle design',
      'Precise beat matching & sound styling',
      'Platform-optimized 9:16 delivery',
    ],
    highlight: 'Synthesized concept imagery and dynamic motion prompts.',
  },
  {
    id: 'resume-portfolio',
    number: '05',
    code: '05 // CAREER-ASSETS',
    title: 'Resume & Portfolio Design',
    icon: 'badge',
    tagline: 'Standout professional resumes and visual portfolio kits designed to highlight your expertise and land career opportunities.',
    description: 'Executive CVs, interactive visual portfolios, and comprehensive personal branding kits that capture attention and open prestigious career opportunities.',
    image: '',
    deliverables: [
      'ATS-friendly executive document architectures',
      'Editorial typography hierarchy & readability',
      'Custom interactive portfolio case-study decks',
      'Print-ready CMYK & web-optimized interactive PDF',
    ],
    highlight: 'Clean visual hierarchies that pass automated scanners & captivate humans.',
  },
];

export const SKILLS_LIST = [
  { name: 'UI/UX Design', percent: 95, desc: 'User Flow, Wireframing, High-Fidelity Prototyping, Design Systems Architecture.', icon: 'layers' },
  { name: 'Figma', percent: 92, desc: 'Auto-layout deep structures, Component variants, Interactive variables, Dev handoff.', icon: 'design_services' },
  { name: 'HTML & CSS', percent: 90, desc: 'Semantic HTML5 tags, CSS Grid, Flexbox, Custom Properties, BEM Architecture.', icon: 'html' },
  { name: 'Bootstrap 5 & Tailwind', percent: 88, desc: 'Responsive layouts, Utility-first styling, Rapid UI assembly, Theme token tailoring.', icon: 'dashboard_customize' },
  { name: 'JavaScript', percent: 80, desc: 'DOM manipulation, Interactive UI logic, Fetch API integrations, ES6+ features.', icon: 'javascript' },
  { name: 'AI Content Creation', percent: 94, desc: 'Prompt engineering, Midjourney exploration, Generative video workflows, Texture creation.', icon: 'smart_toy' },
];

export const TOOLKIT_LIST = [
  { name: 'Figma', category: 'UI/UX', icon: 'draw' },
  { name: 'VS Code', category: 'Editor', icon: 'terminal' },
  { name: 'HTML & CSS', category: 'Markup', icon: 'integration_instructions' },
  { name: 'Bootstrap', category: 'Framework', icon: 'view_quilt' },
  { name: 'Adobe CC', category: 'Visual Suite', icon: 'brush' },
  { name: 'Midjourney', category: 'Gen AI', icon: 'psychology' },
  { name: 'GitHub', category: 'Version Control', icon: 'folder_data' },
  { name: 'Canva', category: 'Fast Socials', icon: 'auto_stories' },
];

export const WORKFLOW_STAGES = [
  {
    step: '01',
    phase: 'Phase 1 • Discovery',
    title: 'Discover',
    icon: 'explore',
    desc: 'Deep-dive briefing, understanding target audience, project objectives, and curated visual inspirations.',
    badge: 'Brief & Research',
  },
  {
    step: '02',
    phase: 'Phase 2 • Architecture',
    title: 'Plan',
    icon: 'schema',
    desc: 'Information architecture, structural low-fi wireframes, page hierarchies, and comprehensive content strategy.',
    badge: 'Wireframing',
  },
  {
    step: '03',
    phase: 'Phase 3 • Execution',
    title: 'Design',
    icon: 'brush',
    desc: 'High-fidelity visual styling, interactive prototypes, design system tokens, typography pairing, and client review cycles.',
    badge: 'UI & Prototyping',
  },
  {
    step: '04',
    phase: 'Phase 4 • Launch',
    title: 'Build & Deliver',
    icon: 'rocket_launch',
    desc: 'Clean HTML/CSS/JS frontend assembly, rigorous responsive & performance checks, and handoff of deployment-ready code.',
    badge: 'Frontend Code',
  },
];

export const FAQ_LIST = [
  {
    id: 'faq-1',
    question: 'What happens after I send a message?',
    answer: 'Within 24 business hours, I review your specifications and schedule a brief 20-minute discovery call or send a customized project proposal outline with milestone timeline estimates.',
  },
  {
    id: 'faq-2',
    question: 'Do you provide code handoff or just design?',
    answer: 'Both. I build end-to-end solutions. You can hire me for Figma UI/UX architecture and brand assets, or for full-stack front-end engineering using modern frameworks and clean, responsive code (HTML5, CSS3, Bootstrap 5, Tailwind, and React).',
  },
  {
    id: 'faq-3',
    question: 'Can we schedule a discovery call?',
    answer: 'Yes, absolutely. Once you submit the contact form with your high-level scope, a direct calendar link will be shared to select a time that fits your schedule across any time zone.',
  },
  {
    id: 'faq-4',
    question: 'Can I get the standalone HTML and Bootstrap code?',
    answer: 'Yes! All pages are built with pure semantic HTML5 and clean CSS/Bootstrap 5 responsive architecture. You can view or download the standalone HTML and Bootstrap files at any time using the code export tool right in the header.',
  },
];
