import React from 'react';
import { Palette, Dribbble, Linkedin, Instagram, Github } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleNav = (page: string) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#ffffff] mt-16 shadow-[0_-1px_12px_rgba(0,0,0,0.03)] border-t border-[#eeedf4]">
      <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12 pt-12 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 pb-10 border-b border-[#eeedf4]">
          {/* Brand Info */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="flex items-center gap-2">
              {/* ========================================================================= */}
              {/* FOOTER LOGO IMAGE: Replace src="" with your footer logo image path */}
              {/* ========================================================================= */}
              <div className="w-8 h-8 rounded-lg bg-[#4d41df] text-white flex items-center justify-center font-extrabold text-sm shadow-sm overflow-hidden relative">
                <img
                  src=""
                  alt="Sailesh Designs Logo"
                  className="w-full h-full object-cover absolute inset-0 z-10"
                  onError={(e) => {
                    (e.currentTarget as HTMLElement).style.display = 'none';
                  }}
                />
                <span>SD</span>
              </div>
              <span className="font-semibold text-xl text-[#1a1b20] tracking-tight">
                Sailesh Designs
              </span>
            </div>
            <p className="text-base text-[#464555] max-w-sm leading-relaxed">
              Creative Designs. Modern Websites. Powerful Visuals.
            </p>
            <div className="flex items-center gap-2 mt-2">
              <a
                href="https://behance.net"
                target="_blank"
                rel="noreferrer"
                aria-label="Behance"
                className="w-10 h-10 rounded-full bg-[#f4f3fa] flex items-center justify-center text-[#464555] hover:bg-[#4d41df] hover:text-white transition-all duration-200"
              >
                <Palette className="w-4 h-4" />
              </a>
              <a
                href="https://dribbble.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Dribbble"
                className="w-10 h-10 rounded-full bg-[#f4f3fa] flex items-center justify-center text-[#464555] hover:bg-[#4d41df] hover:text-white transition-all duration-200"
              >
                <Dribbble className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                aria-label="LinkedIn"
                className="w-10 h-10 rounded-full bg-[#f4f3fa] flex items-center justify-center text-[#464555] hover:bg-[#4d41df] hover:text-white transition-all duration-200"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                aria-label="Instagram"
                className="w-10 h-10 rounded-full bg-[#f4f3fa] flex items-center justify-center text-[#464555] hover:bg-[#4d41df] hover:text-white transition-all duration-200"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                aria-label="GitHub"
                className="w-10 h-10 rounded-full bg-[#f4f3fa] flex items-center justify-center text-[#464555] hover:bg-[#4d41df] hover:text-white transition-all duration-200"
              >
                <Github className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 flex flex-col gap-2">
            <span className="font-semibold text-xs text-[#1a1b20] uppercase tracking-wider mb-2">
              Quick Links
            </span>
            <button
              onClick={() => handleNav('home')}
              className="text-left text-sm text-[#464555] hover:text-[#4d41df] transition-colors cursor-pointer"
            >
              Home
            </button>
            <button
              onClick={() => handleNav('about')}
              className="text-left text-sm text-[#464555] hover:text-[#4d41df] transition-colors cursor-pointer"
            >
              About
            </button>
            <button
              onClick={() => handleNav('gallery')}
              className="text-left text-sm text-[#464555] hover:text-[#4d41df] transition-colors cursor-pointer"
            >
              Gallery
            </button>
            <button
              onClick={() => handleNav('services')}
              className="text-left text-sm text-[#464555] hover:text-[#4d41df] transition-colors cursor-pointer"
            >
              Services
            </button>
            <button
              onClick={() => handleNav('contact')}
              className="text-left text-sm text-[#464555] hover:text-[#4d41df] transition-colors cursor-pointer"
            >
              Contact
            </button>
          </div>

          {/* Services Offered */}
          <div className="lg:col-span-4 flex flex-col gap-2">
            <span className="font-semibold text-xs text-[#1a1b20] uppercase tracking-wider mb-2">
              Services
            </span>
            <div className="flex flex-col gap-1.5 text-sm text-[#464555]">
              <span className="hover:text-[#4d41df] cursor-pointer" onClick={() => handleNav('services')}>
                UI/UX Design
              </span>
              <span className="hover:text-[#4d41df] cursor-pointer" onClick={() => handleNav('services')}>
                Web Development (HTML5, Bootstrap, React)
              </span>
              <span className="hover:text-[#4d41df] cursor-pointer" onClick={() => handleNav('services')}>
                AI Visuals & Reels Creation
              </span>
              <span className="hover:text-[#4d41df] cursor-pointer" onClick={() => handleNav('services')}>
                Resume & Portfolio Design
              </span>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#f4f3fa]/50 px-4 py-3 rounded-xl mt-4">
          <p className="text-xs text-[#464555]">
            © 2025 Sailesh Designs. Designed with precision & passion.
          </p>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-semibold text-[#464555]">
              Available for new projects
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
