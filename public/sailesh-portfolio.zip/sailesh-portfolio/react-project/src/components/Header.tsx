import React, { useState } from 'react';
import { ArrowRight, Code2, Download, Menu, X } from 'lucide-react';

interface HeaderProps {
  activePage: string;
  onNavigate: (page: string) => void;
  onOpenCodeModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activePage, onNavigate, onOpenCodeModal }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'services', label: 'Services' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#ffffff]/85 backdrop-blur-xl shadow-[0_1px_8px_rgba(77,65,223,0.06)] border-b border-[#e2e2e9]/50 transition-all duration-200">
      <div className="h-20 max-w-7xl mx-auto px-4 md:px-8 lg:px-12 flex items-center justify-between">
        {/* Brand Zone */}
        <button
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-2 group text-left cursor-pointer focus:outline-none"
        >
          {/* ========================================================================= */}
          {/* LOGO IMAGE: Replace src="" with your logo image path (e.g. "/assets/logo.png") */}
          {/* ========================================================================= */}
          <div className="w-8 h-8 rounded-lg bg-[#4d41df] text-white flex items-center justify-center font-extrabold text-sm shadow-sm transition-transform group-hover:scale-105 overflow-hidden relative">
            <img
              src=""
              alt="Sailesh Designs Logo"
              className="w-full h-full object-cover absolute inset-0 z-10"
              onError={(e) => {
                // Hides empty/broken image icon so SD text displays until you add your image
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
            <span>SD</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-xl text-[#1a1b20] tracking-tight">
              Sailesh Designs
            </span>
            <span className="bg-[#e3dfff] text-[#100069] text-xs font-semibold px-2 py-0.5 rounded-full uppercase tracking-wider">
              Studio
            </span>
          </div>
        </button>

        {/* Navigation Zone */}
        <nav className="hidden lg:flex items-center gap-1 bg-[#f4f3fa] px-2 py-1 rounded-full border border-[#eeedf4]">
          {navItems.map((item) => {
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-4 py-1.5 rounded-full transition-all duration-200 text-sm font-semibold cursor-pointer ${
                  isActive
                    ? 'bg-[#ffffff] text-[#1a1b20] shadow-sm'
                    : 'text-[#464555] hover:text-[#1a1b20] hover:bg-[#eeedf4]'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Action Zone */}
        <div className="flex items-center gap-2.5">
          {/* Download Complete ZIP Package */}
          <a
            href="/sailesh-designs-portfolio.zip"
            download="sailesh-designs-portfolio.zip"
            title="Download Complete Code Package (HTML, Bootstrap & React ZIP)"
            className="inline-flex items-center gap-1.5 bg-[#4d41df] hover:bg-[#392ebc] text-white text-xs font-semibold px-3.5 py-2 rounded-full shadow-[0_4px_14px_rgba(77,65,223,0.3)] transition-all hover:scale-105 active:scale-95 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Download ZIP</span>
            <span className="sm:hidden">ZIP</span>
          </a>

          {/* Standalone HTML/Bootstrap Code preview trigger */}
          <button
            onClick={onOpenCodeModal}
            title="View HTML & Bootstrap CSS Source Files"
            className="hidden md:inline-flex items-center gap-1.5 bg-[#f4f3fa] hover:bg-[#e8e7ee] text-[#4d41df] text-xs font-semibold px-3 py-2 rounded-full border border-[#c7c4d8]/40 transition-all cursor-pointer"
          >
            <Code2 className="w-3.5 h-3.5 text-[#4d41df]" />
            <span>HTML &amp; Bootstrap</span>
          </button>

          {/* Primary CTA */}
          <button
            onClick={() => handleNavClick('contact')}
            className="hidden lg:inline-flex items-center gap-2 bg-[#f4f3fa] text-[#1a1b20] hover:bg-[#e8e7ee] text-sm font-semibold px-4 py-2 rounded-full border border-[#eeedf4] transition-all duration-200 active:scale-95 cursor-pointer"
          >
            <span>Let's Talk</span>
            <ArrowRight className="w-4 h-4 text-[#4d41df]" />
          </button>

          {/* ========================================================================= */}
          {/* PROFILE AVATAR IMAGE: Replace src="" with your profile image (e.g. "/assets/profile.jpg") */}
          {/* ========================================================================= */}
          <div className="flex items-center pl-1">
            <div className="w-9 h-9 rounded-full bg-[#f4f3fa] text-[#4d41df] font-bold text-xs flex items-center justify-center border-2 border-[#e3dfff] shadow-sm overflow-hidden relative">
              <img
                src=""
                alt="Sailesh Profile Avatar"
                className="w-full h-full object-cover absolute inset-0 z-10"
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }}
              />
              <span>S</span>
            </div>
          </div>

          {/* Mobile Menu Trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl text-[#1a1b20] hover:bg-[#f4f3fa] focus:outline-none cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white/95 backdrop-blur-xl border-b border-[#e2e2e9] px-6 py-4 shadow-xl animate-fadeIn">
          <nav className="flex flex-col gap-2">
            {navItems.map((item) => {
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center justify-between px-4 py-3 rounded-xl text-left font-semibold text-base transition-colors ${
                    isActive
                      ? 'bg-[#e3dfff] text-[#100069]'
                      : 'text-[#464555] hover:bg-[#f4f3fa] hover:text-[#1a1b20]'
                  }`}
                >
                  <span>{item.label}</span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-[#4d41df]"></span>}
                </button>
              );
            })}
            <div className="pt-2 border-t border-[#eeedf4] flex flex-col gap-2">
              <a
                href="/sailesh-designs-portfolio.zip"
                download="sailesh-designs-portfolio.zip"
                className="flex items-center justify-center gap-2 bg-[#4d41df] text-white py-3 rounded-xl font-semibold text-sm shadow-md cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download Entire Code ZIP (.zip)</span>
              </a>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenCodeModal();
                }}
                className="flex items-center justify-center gap-2 bg-[#f4f3fa] text-[#4d41df] py-3 rounded-xl font-semibold text-sm"
              >
                <Code2 className="w-4 h-4" />
                <span>HTML & Bootstrap Source Files</span>
              </button>
              <button
                onClick={() => handleNavClick('contact')}
                className="flex items-center justify-center gap-2 bg-[#4d41df] text-white py-3 rounded-xl font-semibold text-sm shadow-md"
              >
                <span>Let's Talk</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
