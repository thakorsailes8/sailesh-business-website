import React, { useEffect } from 'react';
import { ProjectItem } from '../data/portfolioData';
import { X, CheckCircle2, ArrowRight, ExternalLink } from 'lucide-react';

interface CaseStudyModalProps {
  project: ProjectItem | null;
  onClose: () => void;
  onSelectProjectForContact: (projectTitle: string, category: string) => void;
}

export const CaseStudyModal: React.FC<CaseStudyModalProps> = ({
  project,
  onClose,
  onSelectProjectForContact,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (project) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [project, onClose]);

  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-md animate-fadeIn">
      <div
        className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-white rounded-3xl shadow-2xl border border-[#eeedf4] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between px-6 py-4 bg-white/90 backdrop-blur-md border-b border-[#eeedf4]">
          <div className="flex items-center gap-2">
            <span className="bg-[#e3dfff] text-[#100069] text-xs font-semibold px-3 py-1 rounded-full uppercase tracking-wider">
              {project.categoryLabel}
            </span>
            <span className="text-xs text-[#5f5e64]">·</span>
            <span className="text-xs text-[#5f5e64]">{project.year}</span>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#f4f3fa] hover:bg-[#e8e7ee] text-[#1a1b20] flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 md:p-8 flex flex-col gap-8">
          {/* Header Info */}
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-[#1a1b20] tracking-tight mb-2">
              {project.title}
            </h2>
            <p className="text-base text-[#464555] leading-relaxed">
              {project.description}
            </p>
          </div>

          {/* Project Media Showcase Canvas (Pure Vector Architecture) */}
          <div className="relative aspect-[16/9] md:aspect-[21/9] rounded-2xl overflow-hidden bg-gradient-to-br from-[#121422] via-[#1a1b30] to-[#252347] border border-[#e2e2e9] shadow-inner p-6 flex flex-col justify-between">
            {/* ========================================================================= */}
            {/* CASE STUDY MODAL BANNER IMAGE: Replace src="" with project showcase image */}
            {/* Or set in portfolioData.ts (project.image) */}
            {/* ========================================================================= */}
            <img
              src={project.image || ""}
              alt={project.title}
              className="w-full h-full object-cover absolute inset-0 z-0"
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />

            {/* Ambient Background Grid */}
            <div
              className="absolute inset-0 opacity-15 pointer-events-none"
              style={{
                backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)',
                backgroundSize: '24px 24px',
              }}
            ></div>

            {/* Top Bar of Showcase Canvas */}
            <div className="relative z-10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                <span className="text-xs font-mono font-bold text-white tracking-wider">{project.tools}</span>
              </div>
              <span className="px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-mono text-purple-300 border border-white/10">
                {project.year} Production Release
              </span>
            </div>

            {/* Central Vector Diagram */}
            <div className="relative z-10 my-auto flex flex-col sm:flex-row items-center justify-center gap-6 text-center sm:text-left py-4">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#4d41df] to-[#857dfa] p-1 shadow-[0_0_30px_rgba(77,65,223,0.4)] flex items-center justify-center text-white shrink-0">
                <span className="text-xl font-extrabold tracking-tight">SD</span>
              </div>
              <div className="flex flex-col gap-1 max-w-md">
                <span className="text-xs font-mono text-[#a49dfa] uppercase tracking-wider">{project.categoryLabel} Architecture</span>
                <h3 className="text-lg md:text-xl font-bold text-white leading-tight">{project.subtitle}</h3>
                <p className="text-xs text-white/70 font-mono">Status: Verified Production Standards • Modular Tokens</p>
              </div>
            </div>

            {/* Bottom Bar of Showcase Canvas */}
            <div className="relative z-10 flex items-center justify-between text-xs text-white/60 font-mono pt-3 border-t border-white/10">
              <span>Client: {project.client}</span>
              <span className="text-emerald-400 font-semibold">{project.metrics || '100% Quality Benchmark'}</span>
            </div>
          </div>

          {/* Case Study Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* The Challenge */}
            <div className="bg-[#f4f3fa] p-6 rounded-2xl border border-[#eeedf4]">
              <h3 className="text-xs uppercase tracking-wider font-bold text-[#4d41df] mb-2">
                The Challenge
              </h3>
              <p className="text-sm text-[#464555] leading-relaxed">
                {project.challenge || 'Client required a modern aesthetic redesign that elevated brand authority, improved cross-device responsiveness, and streamlined the user interaction flow.'}
              </p>
            </div>

            {/* The Solution */}
            <div className="bg-[#f4f3fa] p-6 rounded-2xl border border-[#eeedf4]">
              <h3 className="text-xs uppercase tracking-wider font-bold text-[#4d41df] mb-2">
                The Solution
              </h3>
              <p className="text-sm text-[#464555] leading-relaxed">
                {project.solution || 'Engineered an intuitive component architecture with bespoke visual styling, accessible color tokens, and performant frontend code.'}
              </p>
            </div>
          </div>

          {/* Deliverables & Stack */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className="md:col-span-7 flex flex-col gap-3">
              <h3 className="text-xs uppercase tracking-wider font-bold text-[#1a1b20]">
                Key Deliverables
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(project.deliverables || [
                  'High-Fidelity Wireframes',
                  'Component Design Tokens',
                  'Interactive Clickable Flow',
                  'Responsive Frontend Code',
                ]).map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm text-[#464555]">
                    <CheckCircle2 className="w-4 h-4 text-[#4d41df] shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="md:col-span-5 bg-[#faf8ff] p-5 rounded-2xl border border-[#e3dfff] flex flex-col justify-between">
              <div>
                <span className="text-xs uppercase tracking-wider font-bold text-[#4d41df] block mb-1">
                  Tools & Architecture
                </span>
                <p className="text-sm font-semibold text-[#1a1b20] mb-3">
                  {project.tools}
                </p>
                {project.metrics && (
                  <div>
                    <span className="text-xs uppercase tracking-wider font-bold text-[#100069] block mb-0.5">
                      Measured Impact
                    </span>
                    <p className="text-sm text-[#3622ca] font-medium">
                      {project.metrics}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Bottom Action */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-[#eeedf4]">
            <div className="flex items-center gap-2 text-xs text-[#5f5e64]">
              <ExternalLink className="w-4 h-4 text-[#4d41df]" />
              <span>Full assets available for client inspection</span>
            </div>
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 rounded-full border border-[#c7c4d8] text-sm font-semibold text-[#1a1b20] hover:bg-[#f4f3fa] transition-colors cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  onSelectProjectForContact(project.title, project.category);
                  onClose();
                }}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-full bg-[#4d41df] hover:bg-[#675df9] text-white text-sm font-semibold shadow-md transition-all cursor-pointer"
              >
                <span>Discuss Similar Project</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
