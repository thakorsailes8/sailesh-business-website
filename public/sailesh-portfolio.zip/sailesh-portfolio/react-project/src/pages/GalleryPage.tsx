import React, { useState } from 'react';
import { ArrowRight, ExternalLink, Play, Sparkles, SlidersHorizontal, Lock, MoreHorizontal } from 'lucide-react';
import { PORTFOLIO_PROJECTS, ProjectItem } from '../data/portfolioData';

interface GalleryPageProps {
  onNavigate: (page: string) => void;
  onOpenCaseStudy: (project: ProjectItem) => void;
}

export const GalleryPage: React.FC<GalleryPageProps> = ({ onNavigate, onOpenCaseStudy }) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');

  const filterTabs = [
    { id: 'all', label: 'All' },
    { id: 'social', label: 'Social Media Posts' },
    { id: 'websites', label: 'Websites' },
    { id: 'ai-video', label: 'AI Videos' },
    { id: 'uiux', label: 'UI/UX' },
    { id: 'resumes', label: 'Resume Designs' },
  ];

  const spotlightProject = PORTFOLIO_PROJECTS.find((p) => p.isSpotlight) || PORTFOLIO_PROJECTS[0];
  const gridProjects = PORTFOLIO_PROJECTS.filter((p) => !p.isSpotlight);

  const filteredProjects = selectedFilter === 'all'
    ? gridProjects
    : gridProjects.filter((p) => p.category === selectedFilter);

  return (
    <div className="flex flex-col w-full">
      {/* Subtle Ambient Glows */}
      <div className="relative w-full overflow-hidden">
        <div className="absolute top-12 left-1/4 w-96 h-96 bg-[#4d41df]/10 rounded-full blur-3xl pointer-events-none -z-10"></div>
        <div className="absolute top-96 right-12 w-80 h-80 bg-[#e3dfff]/20 rounded-full blur-3xl pointer-events-none -z-10"></div>

        {/* Header Section */}
        <section className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12 pt-10 pb-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 bg-[#f4f3fa] px-4 py-1 rounded-full shadow-sm mb-4 border border-[#eeedf4]">
                <span className="w-2 h-2 rounded-full bg-[#4d41df] animate-ping"></span>
                <span className="text-xs text-[#464555] font-medium">Curated Works Portfolio</span>
                <span className="text-[#c7c4d8] text-xs">·</span>
                <span className="text-xs text-[#4d41df] font-semibold">2024–2025 Volume</span>
              </div>
              <h1 className="text-4xl md:text-5xl font-extrabold text-[#1a1b20] tracking-tight mb-2">
                My Creative Work
              </h1>
              <p className="text-base sm:text-lg text-[#464555] max-w-2xl leading-relaxed">
                A selection of designs, websites, videos, and creative projects built with aesthetic discipline and modern digital craftsmanship.
              </p>
            </div>

            {/* Metric Pill */}
            <div className="bg-white px-5 py-3.5 rounded-2xl shadow-sm border border-[#eeedf4] flex items-center gap-3 self-start md:self-auto">
              <div className="w-10 h-10 rounded-xl bg-[#e3dfff] flex items-center justify-center text-[#4d41df]">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-bold text-[#1a1b20]">Showing 9 Curated Projects</span>
                <span className="text-xs text-[#5f5e64]">Multi-Disciplinary Studio Archive</span>
              </div>
            </div>
          </div>

          {/* Filter Controls Bar */}
          <div className="mt-8 flex items-center justify-between gap-4 overflow-x-auto pb-2 scrollbar-none">
            <div className="flex items-center gap-1.5 bg-[#f4f3fa] p-1.5 rounded-full shadow-sm border border-[#eeedf4]">
              {filterTabs.map((tab) => {
                const isActive = selectedFilter === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setSelectedFilter(tab.id)}
                    className={`px-4 py-2 rounded-full text-xs sm:text-sm font-semibold transition-all duration-200 cursor-pointer whitespace-nowrap ${
                      isActive
                        ? 'bg-[#4d41df] text-white shadow-sm'
                        : 'text-[#464555] hover:text-[#1a1b20] hover:bg-[#eeedf4]'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>

            <div className="hidden lg:flex items-center gap-2 text-[#5f5e64] text-xs font-semibold">
              <SlidersHorizontal className="w-4 h-4 text-[#4d41df]" />
              <span>Fluid Studio Grid</span>
            </div>
          </div>
        </section>

        {/* Featured Spotlight Card */}
        <section className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12 py-6">
          <div className="relative bg-white rounded-3xl p-6 lg:p-8 shadow-md border border-[#eeedf4] overflow-hidden group">
            <div className="absolute -right-24 -bottom-24 w-96 h-96 bg-[#e3dfff]/20 rounded-full blur-2xl pointer-events-none"></div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              {/* Text Metadata */}
              <div className="lg:col-span-5 flex flex-col justify-between h-full">
                <div>
                  <div className="flex items-center gap-2 mb-4">
                    <span className="px-3 py-1 bg-[#e3dfff] text-[#100069] text-xs font-semibold rounded-full uppercase tracking-wider">
                      Featured Spotlight
                    </span>
                    <span className="px-3 py-1 bg-[#eeedf4] text-[#464555] text-xs font-semibold rounded-full">
                      Case Study
                    </span>
                  </div>

                  <h2 className="text-2xl md:text-3xl font-extrabold text-[#1a1b20] tracking-tight mb-3">
                    {spotlightProject.title}
                  </h2>
                  <p className="text-sm text-[#464555] mb-6 leading-relaxed">
                    {spotlightProject.description}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-6">
                    <span className="px-3 py-1 bg-[#f4f3fa] text-[#1a1b20] text-xs font-semibold rounded-full border border-[#eeedf4]">
                      UI/UX Architecture
                    </span>
                    <span className="px-3 py-1 bg-[#f4f3fa] text-[#1a1b20] text-xs font-semibold rounded-full border border-[#eeedf4]">
                      Design Systems
                    </span>
                    <span className="px-3 py-1 bg-[#f4f3fa] text-[#1a1b20] text-xs font-semibold rounded-full border border-[#eeedf4]">
                      Responsive Web App
                    </span>
                    <span className="px-3 py-1 bg-[#f4f3fa] text-[#1a1b20] text-xs font-semibold rounded-full border border-[#eeedf4]">
                      Interactive Prototypes
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <button
                    onClick={() => onOpenCaseStudy(spotlightProject)}
                    className="inline-flex items-center gap-2 bg-[#4d41df] text-white text-sm font-semibold px-6 py-3 rounded-full shadow-[0_8px_24px_rgba(77,65,223,0.3)] hover:bg-[#675df9] transition-all duration-200 hover:-translate-y-0.5 cursor-pointer"
                  >
                    <span>View Project Details</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                  <span className="text-xs text-[#5f5e64]">
                    Client: {spotlightProject.client}
                  </span>
                </div>
              </div>

              {/* Browser Mockup Window */}
              <div className="lg:col-span-7">
                <div
                  onClick={() => onOpenCaseStudy(spotlightProject)}
                  className="bg-[#e8e7ee] rounded-2xl p-2 shadow-xl overflow-hidden transition-transform duration-500 group-hover:scale-[1.01] cursor-pointer"
                >
                  <div className="flex items-center justify-between px-4 py-2 bg-[#e2e2e9] rounded-t-xl mb-1.5">
                    <div className="flex items-center gap-1.5">
                      <div className="w-3 h-3 rounded-full bg-[#ba1a1a]/70"></div>
                      <div className="w-3 h-3 rounded-full bg-amber-400/70"></div>
                      <div className="w-3 h-3 rounded-full bg-emerald-500/70"></div>
                    </div>
                    <div className="px-4 py-0.5 bg-white rounded-full text-[11px] text-[#5f5e64] tracking-wide flex items-center gap-1.5 shadow-sm">
                      <Lock className="w-3 h-3 text-[#4d41df]" />
                      <span>apex-platform.design/preview</span>
                    </div>
                    <div className="w-10 flex justify-end text-[#777587]">
                      <MoreHorizontal className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Pure Vector Apex Fintech Trading Terminal Mockup */}
                  <div className="relative aspect-[16/10] rounded-b-xl overflow-hidden bg-[#0d0f17] p-4 text-left border-t border-white/5 flex flex-col justify-between">
                    {/* ========================================================================= */}
                    {/* GALLERY SPOTLIGHT PROJECT IMAGE: Replace src="" with your spotlight case study image */}
                    {/* Example: src={spotlightProject.image || "/assets/spotlight-apex.jpg"} */}
                    {/* ========================================================================= */}
                    <img
                      src={spotlightProject.image || ""}
                      alt={spotlightProject.title}
                      className="w-full h-full object-cover absolute inset-0 z-10 transition-transform duration-700 group-hover:scale-105"
                      onError={(e) => {
                        (e.currentTarget as HTMLElement).style.display = 'none';
                      }}
                    />

                    <div className="flex items-center justify-between border-b border-white/10 pb-2 relative z-20">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                        <span className="text-xs font-mono font-bold text-white tracking-wider">APEX TERMINAL v4.2</span>
                        <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">BTC/USD $94,820.50 (+4.6%)</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] font-mono text-white/50">
                        <span>1s Interval</span>
                        <span className="text-[#a49dfa] bg-[#4d41df]/20 px-2 py-0.5 rounded">Orderbook: Live</span>
                      </div>
                    </div>

                    {/* Candlestick & Spline Vector SVG Chart */}
                    <div className="relative h-28 w-full my-auto flex items-center justify-center">
                      <svg viewBox="0 0 500 120" className="w-full h-full" preserveAspectRatio="none">
                        <defs>
                          <linearGradient id="apexGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="#4d41df" stopOpacity="0.4" />
                            <stop offset="100%" stopColor="#4d41df" stopOpacity="0" />
                          </linearGradient>
                        </defs>
                        {/* Grid lines */}
                        <line x1="0" y1="30" x2="500" y2="30" stroke="#ffffff" strokeOpacity="0.05" strokeDasharray="3 3" />
                        <line x1="0" y1="60" x2="500" y2="60" stroke="#ffffff" strokeOpacity="0.05" strokeDasharray="3 3" />
                        <line x1="0" y1="90" x2="500" y2="90" stroke="#ffffff" strokeOpacity="0.05" strokeDasharray="3 3" />
                        {/* Area gradient */}
                        <path
                          d="M0,90 Q70,70 140,50 T280,35 T420,20 L500,10 L500,120 L0,120 Z"
                          fill="url(#apexGrad)"
                        />
                        {/* Glow Spline Line */}
                        <path
                          d="M0,90 Q70,70 140,50 T280,35 T420,20 L500,10"
                          fill="none"
                          stroke="#857dfa"
                          strokeWidth="3"
                          strokeLinecap="round"
                        />
                        {/* Candlestick bars */}
                        <rect x="40" y="65" width="6" height="25" fill="#10b981" rx="1" />
                        <rect x="100" y="55" width="6" height="20" fill="#10b981" rx="1" />
                        <rect x="180" y="45" width="6" height="28" fill="#10b981" rx="1" />
                        <rect x="250" y="38" width="6" height="22" fill="#ef4444" rx="1" />
                        <rect x="330" y="28" width="6" height="30" fill="#10b981" rx="1" />
                        <rect x="420" y="15" width="6" height="25" fill="#10b981" rx="1" />
                        <circle cx="500" cy="10" r="4" fill="#a49dfa" />
                      </svg>
                    </div>

                    <div className="flex items-center justify-between text-[10px] font-mono text-white/50 pt-2 border-t border-white/10">
                      <span>Liquidity Depth: 99.8% Match</span>
                      <span className="text-[#a49dfa] flex items-center gap-1">
                        Inspect Prototype Details <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Curated Portfolio Project Grid */}
        <section className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12 py-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold text-[#1a1b20] tracking-tight">
                Curated Works Collection
              </h3>
              <p className="text-xs sm:text-sm text-[#5f5e64]">
                Dynamic filterable archive across disciplines
              </p>
            </div>
            <div className="text-[#5f5e64] text-xs font-semibold flex items-center gap-1">
              <span>{filteredProjects.length} Filtered Entries</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <article
                key={project.id}
                onClick={() => onOpenCaseStudy(project)}
                className="flex flex-col bg-white rounded-2xl overflow-hidden shadow-sm border border-[#eeedf4] hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group cursor-pointer"
              >
                {/* Pure Vector Project Showcase Graphic */}
                <div className="relative aspect-[16/10] overflow-hidden bg-gradient-to-br from-[#121422] to-[#1e1e2f] p-4 flex flex-col justify-between group-hover:scale-[1.02] transition-transform duration-500">
                  {/* ========================================================================= */}
                  {/* GALLERY PROJECT CARD IMAGE: Replace src="" with project image or set in portfolioData.ts */}
                  {/* Example: src={project.image || "/assets/project.jpg"} */}
                  {/* ========================================================================= */}
                  <img
                    src={project.image || ""}
                    alt={project.title}
                    className="w-full h-full object-cover absolute inset-0 z-0 transition-transform duration-500 group-hover:scale-105"
                    onError={(e) => {
                      (e.currentTarget as HTMLElement).style.display = 'none';
                    }}
                  />

                  {/* Subtle Grid Pattern */}
                  <div
                    className="absolute inset-0 opacity-10 pointer-events-none"
                    style={{
                      backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)',
                      backgroundSize: '16px 16px',
                    }}
                  ></div>

                  {/* Top Badges */}
                  <div className="relative z-10 flex items-center justify-between">
                    <span className="px-3 py-1 bg-white/90 backdrop-blur-md text-[#4d41df] text-xs font-bold rounded-full shadow-sm">
                      {project.categoryLabel}
                    </span>
                    <span className="px-2.5 py-0.5 bg-black/50 backdrop-blur-md text-white/90 text-[11px] rounded-md font-mono">
                      {project.tag}
                    </span>
                  </div>

                  {/* Vector Core Graphic by Category */}
                  <div className="relative z-10 my-auto flex flex-col items-center justify-center text-center px-4">
                    {project.category === 'uiux' && (
                      <div className="w-full max-w-[220px] bg-white/10 rounded-xl p-2.5 border border-white/15 flex flex-col gap-2">
                        <div className="flex items-center justify-between">
                          <div className="w-16 h-2 bg-purple-400 rounded"></div>
                          <span className="text-[8px] font-mono text-emerald-400">● 99.4% Flow</span>
                        </div>
                        <div className="h-6 w-full flex items-end gap-1.5 pt-1">
                          <div className="flex-1 bg-[#857dfa]/40 h-3 rounded-sm"></div>
                          <div className="flex-1 bg-[#857dfa]/70 h-5 rounded-sm"></div>
                          <div className="flex-1 bg-[#4d41df] h-6 rounded-sm"></div>
                          <div className="flex-1 bg-[#857dfa]/80 h-4 rounded-sm"></div>
                        </div>
                      </div>
                    )}

                    {project.category === 'websites' && (
                      <div className="w-full max-w-[220px] bg-white/10 rounded-xl p-2.5 border border-white/15 flex flex-col gap-2">
                        <div className="flex items-center gap-1 border-b border-white/10 pb-1.5">
                          <div className="w-1.5 h-1.5 rounded-full bg-rose-400"></div>
                          <div className="w-1.5 h-1.5 rounded-full bg-amber-400"></div>
                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400"></div>
                          <span className="text-[8px] text-white/50 ml-1 font-mono">https://modern-web.site</span>
                        </div>
                        <div className="text-left space-y-1">
                          <div className="w-24 h-2 bg-white/80 rounded"></div>
                          <div className="w-32 h-1 bg-white/40 rounded"></div>
                        </div>
                      </div>
                    )}

                    {project.category === 'social' && (
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-16 rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 p-2 flex flex-col justify-between text-left shadow-lg">
                          <span className="text-[8px] font-bold text-white leading-none">VIRAL</span>
                          <span className="text-[7px] text-white/80">#Growth</span>
                        </div>
                        <div className="text-left font-mono text-[9px] text-white/80">
                          <div className="text-pink-300 font-bold">+310% Reach</div>
                          <div className="text-white/50">Multi-Slide Pack</div>
                        </div>
                      </div>
                    )}

                    {project.category === 'ai-video' && (
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-12 h-12 rounded-full bg-white/90 text-[#4d41df] flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                          <Play className="w-5 h-5 fill-current ml-0.5" />
                        </div>
                        <span className="text-[10px] font-mono text-purple-300">4K Cinematic 60fps</span>
                      </div>
                    )}

                    {project.category === 'resumes' && (
                      <div className="w-full max-w-[200px] bg-white/10 rounded-lg p-2.5 border border-white/15 text-left flex flex-col gap-1.5">
                        <div className="flex justify-between items-center">
                          <div className="w-14 h-2 bg-emerald-400 rounded"></div>
                          <span className="text-[8px] font-mono text-emerald-300">ATS 99</span>
                        </div>
                        <div className="w-full h-1 bg-white/30 rounded"></div>
                        <div className="w-3/4 h-1 bg-white/20 rounded"></div>
                      </div>
                    )}
                  </div>

                  {/* Bottom Tool Spec */}
                  <div className="relative z-10 flex items-center justify-between text-[10px] text-white/50 font-mono pt-2 border-t border-white/10">
                    <span>{project.client}</span>
                    <span className="text-[#a49dfa] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      Inspect <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>

                <div className="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <h4 className="text-lg font-bold text-[#1a1b20] mb-1 group-hover:text-[#4d41df] transition-colors">
                      {project.title}
                    </h4>
                    <p className="text-xs sm:text-sm text-[#464555] line-clamp-2 mb-4 leading-relaxed">
                      {project.description}
                    </p>
                  </div>

                  <div className="pt-3 flex items-center justify-between border-t border-[#eeedf4] mt-2 bg-[#f4f3fa]/50 p-3 rounded-xl">
                    <div className="flex items-center gap-1.5 text-[#5f5e64] text-xs">
                      <span>{project.tools}</span>
                    </div>
                    <span className="text-xs font-bold text-[#4d41df] flex items-center gap-1 group-hover:gap-1.5 transition-all">
                      <span>View</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* Project Metrics Strip */}
        <section className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12 py-6">
          <div className="bg-[#f4f3fa] rounded-3xl p-6 md:p-8 border border-[#eeedf4]">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left">
              <div className="flex flex-col gap-1">
                <span className="text-3xl md:text-4xl font-extrabold text-[#4d41df] tracking-tight">
                  45+
                </span>
                <span className="text-sm font-bold text-[#1a1b20]">Delivered Works</span>
                <span className="text-xs text-[#5f5e64]">Across 8 creative domains</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-3xl md:text-4xl font-extrabold text-[#1a1b20] tracking-tight">
                  99.4%
                </span>
                <span className="text-sm font-bold text-[#1a1b20]">Client Satisfaction</span>
                <span className="text-xs text-[#5f5e64]">Based on verified reviews</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-3xl md:text-4xl font-extrabold text-[#4d41df] tracking-tight">
                  12x
                </span>
                <span className="text-sm font-bold text-[#1a1b20]">Average Engagement</span>
                <span className="text-xs text-[#5f5e64]">Elevated social conversion</span>
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-3xl md:text-4xl font-extrabold text-[#1a1b20] tracking-tight">
                  &lt;48h
                </span>
                <span className="text-sm font-bold text-[#1a1b20]">Concept Sprint</span>
                <span className="text-xs text-[#5f5e64]">Rapid iterative delivery</span>
              </div>
            </div>
          </div>
        </section>

        {/* Bottom Conversion Block */}
        <section className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12 pt-6 pb-16">
          <div className="relative bg-[#2f3035] rounded-3xl p-8 md:p-14 overflow-hidden text-center flex flex-col items-center">
            <div className="absolute -top-32 -left-32 w-80 h-80 bg-[#4d41df]/30 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute -bottom-32 -right-32 w-80 h-80 bg-[#675df9]/30 rounded-full blur-3xl pointer-events-none"></div>

            <div className="relative z-10 max-w-2xl flex flex-col items-center">
              <span className="px-4 py-1 bg-[#4d41df]/20 text-[#c4c0ff] text-xs font-bold rounded-full uppercase tracking-wider mb-4">
                Let's Collaborate
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-[#f1f0f7] tracking-tight mb-4">
                Inspired by what you see? Let's create your next flagship project.
              </h2>
              <p className="text-sm md:text-base text-[#c7c4d8] mb-8 max-w-xl leading-relaxed">
                Whether you need a bespoke digital interface, high-converting social campaign visuals, or motion art, Sailesh Designs brings precision and creative audacity.
              </p>
              <div className="flex flex-col sm:flex-row items-center gap-4 w-full justify-center">
                <button
                  onClick={() => onNavigate('contact')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#4d41df] text-white text-sm font-semibold px-8 py-3.5 rounded-full shadow-[0_8px_24px_rgba(77,65,223,0.4)] hover:bg-[#675df9] transition-all duration-200 hover:-translate-y-0.5 cursor-pointer"
                >
                  <span>Discuss a Project</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onNavigate('services')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-[#f1f0f7] text-sm font-semibold px-8 py-3.5 rounded-full transition-all duration-200 cursor-pointer"
                >
                  <span>Explore Services</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
