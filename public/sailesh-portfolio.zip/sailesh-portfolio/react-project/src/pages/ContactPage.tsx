import React, { useState } from 'react';
import { Mail, Send, Calendar, Lock, CheckCircle2, ChevronDown, MessageSquare, Instagram, Globe, Sparkles } from 'lucide-react';
import { FAQ_LIST } from '../data/portfolioData';

interface ContactPageProps {
  initialService?: string;
}

export const ContactPage: React.FC<ContactPageProps> = ({ initialService }) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [service, setService] = useState(initialService || 'webdev');
  const [timeline, setTimeline] = useState('standard');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // Accordion state
  const [expandedFaq, setExpandedFaq] = useState<string | null>('faq-1');

  const toggleFaq = (id: string) => {
    setExpandedFaq(expandedFaq === id ? null : id);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 800);
  };

  return (
    <div className="flex flex-col w-full">
      {/* Ambient Radial Glows */}
      <div className="relative w-full overflow-hidden">
        <div className="absolute -top-40 left-1/4 w-[600px] h-[600px] bg-[#675df9]/10 rounded-full blur-[140px] pointer-events-none -z-10"></div>
        <div className="absolute top-96 right-10 w-[500px] h-[500px] bg-[#e3dfff]/20 rounded-full blur-[120px] pointer-events-none -z-10"></div>

        <div className="max-w-7xl mx-auto px-4 md:px-8 lg:px-12 py-10">
          {/* Top Page Header */}
          <section className="flex flex-col items-start gap-4 mb-12 relative">
            <div className="inline-flex items-center gap-2 bg-[#e8e7ee]/80 backdrop-blur-md px-4 py-1.5 rounded-full shadow-sm">
              <span className="text-[#4d41df] font-bold text-sm">⚡</span>
              <span className="text-xs text-[#464555] font-semibold tracking-wide">
                Typically responds within 24 business hours
              </span>
            </div>

            <div className="flex flex-col md:flex-row md:items-end justify-between w-full gap-6">
              <div>
                <h1 className="text-4xl md:text-5xl font-extrabold text-[#1a1b20] tracking-tight max-w-2xl">
                  Let's Create Something <span className="text-[#4d41df]">Amazing</span>.
                </h1>
                <p className="text-base sm:text-lg text-[#464555] mt-2 max-w-xl leading-relaxed">
                  Have a project in mind? Tell me what you need. From bespoke interfaces to scalable code architecture, let’s turn vision into reality.
                </p>
              </div>

              {/* Micro Stat Pod */}
              <div className="flex items-center gap-4 bg-white shadow-md border border-[#eeedf4] rounded-2xl px-6 py-4 self-start md:self-auto">
                <div className="flex flex-col">
                  <span className="text-[11px] text-[#5f5e64] uppercase tracking-wider font-semibold">
                    Current Pipeline
                  </span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
                    <span className="text-lg font-bold text-[#1a1b20]">3 Slots Left</span>
                  </div>
                </div>
                <div className="w-10 h-10 rounded-full bg-[#f4f3fa] flex items-center justify-center text-[#4d41df]">
                  <Calendar className="w-5 h-5" />
                </div>
              </div>
            </div>
          </section>

          {/* Two-Column Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Form */}
            <div className="lg:col-span-7 bg-white rounded-3xl p-6 md:p-8 shadow-[0px_12px_32px_-8px_rgba(108,99,255,0.12),0px_4px_16px_-4px_rgba(15,15,20,0.04)] border border-[#eeedf4] relative">
              <div className="flex items-center justify-between pb-3 mb-6 bg-[#f4f3fa] px-4 py-2.5 rounded-xl border border-[#eeedf4]">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-[#4d41df]"></span>
                  <span className="text-xs sm:text-sm text-[#1a1b20] font-semibold tracking-wide">
                    Project Scope Inquiry
                  </span>
                </div>
                <span className="text-[11px] text-[#464555] bg-white px-3 py-0.5 rounded-full shadow-sm font-medium">
                  Form • 1-2 min
                </span>
              </div>

              {submitted ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-8 text-center flex flex-col items-center gap-3 animate-fadeIn">
                  <div className="w-14 h-14 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 mb-1">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-emerald-950">
                    Message Sent Successfully!
                  </h3>
                  <p className="text-sm text-emerald-800 max-w-md">
                    Thank you, <span className="font-semibold">{fullName || 'friend'}</span>. Your inquiry has been received. Sailesh will review your requirements and respond via <span className="font-semibold">{email || 'your email'}</span> within 24 business hours.
                  </p>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setFullName('');
                      setEmail('');
                      setMessage('');
                    }}
                    className="mt-3 px-6 py-2 rounded-full bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-semibold shadow-sm transition-colors cursor-pointer"
                  >
                    Submit Another Inquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                  {/* Name and Email */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-semibold text-[#1a1b20] flex items-center justify-between" htmlFor="fullName">
                        <span>Full Name</span>
                        <span className="text-[#ba1a1a]">*</span>
                      </label>
                      <input
                        id="fullName"
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="e.g. Alex Morgan"
                        className="w-full bg-[#f4f3fa] focus:bg-white text-[#1a1b20] placeholder:text-[#777587] text-sm px-4 py-3 rounded-xl transition-all duration-200 outline-none border border-transparent focus:border-[#4d41df] focus:ring-2 focus:ring-[#4d41df]/20"
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-semibold text-[#1a1b20] flex items-center justify-between" htmlFor="emailAddr">
                        <span>Email Address</span>
                        <span className="text-[#ba1a1a]">*</span>
                      </label>
                      <input
                        id="emailAddr"
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="e.g. alex@company.com"
                        className="w-full bg-[#f4f3fa] focus:bg-white text-[#1a1b20] placeholder:text-[#777587] text-sm px-4 py-3 rounded-xl transition-all duration-200 outline-none border border-transparent focus:border-[#4d41df] focus:ring-2 focus:ring-[#4d41df]/20"
                      />
                    </div>
                  </div>

                  {/* Service Required */}
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-semibold text-[#1a1b20] flex items-center justify-between" htmlFor="serviceType">
                      <span>Service Required</span>
                      <span className="text-[#ba1a1a]">*</span>
                    </label>
                    <select
                      id="serviceType"
                      required
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      className="w-full bg-[#f4f3fa] focus:bg-white text-[#1a1b20] text-sm px-4 py-3 rounded-xl transition-all duration-200 outline-none border border-transparent focus:border-[#4d41df] focus:ring-2 focus:ring-[#4d41df]/20 cursor-pointer"
                    >
                      <option value="uiux">UI/UX Design</option>
                      <option value="webdev">Website Design &amp; Development</option>
                      <option value="social">Social Media &amp; Marketing Posts</option>
                      <option value="aivideo">AI Video &amp; Reels Creation</option>
                      <option value="resume">Resume &amp; Portfolio Design</option>
                      <option value="custom">Multiple / Custom Project</option>
                    </select>
                  </div>

                  {/* Project Timeline */}
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-semibold text-[#1a1b20]">
                      Project Timeline Target
                    </label>
                    <div className="grid grid-cols-3 gap-3 pt-0.5">
                      {[
                        { id: 'urgent', label: '< 2 Weeks', desc: 'Rush Sprint' },
                        { id: 'standard', label: '~ 1 Month', desc: 'Standard Pace' },
                        { id: 'flexible', label: 'Flexible', desc: 'Open Timeline' },
                      ].map((t) => (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => setTimeline(t.id)}
                          className={`p-3 text-center rounded-xl text-xs font-semibold transition-all cursor-pointer flex flex-col items-center gap-1 border ${
                            timeline === t.id
                              ? 'bg-[#4d41df] text-white border-[#4d41df] shadow-md'
                              : 'bg-[#f4f3fa] text-[#464555] border-[#eeedf4] hover:bg-[#eeedf4]'
                          }`}
                        >
                          <span>{t.label}</span>
                          <span className={`text-[10px] ${timeline === t.id ? 'text-white/80' : 'text-[#777587]'}`}>
                            {t.desc}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Project Goals */}
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-semibold text-[#1a1b20] flex items-center justify-between" htmlFor="projectDetails">
                      <span>Project Goals &amp; Scope</span>
                      <span className="text-[11px] text-[#777587]">Optional references</span>
                    </label>
                    <textarea
                      id="projectDetails"
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Describe your project goals, deliverables, and any references you like..."
                      className="w-full bg-[#f4f3fa] focus:bg-white text-[#1a1b20] placeholder:text-[#777587] text-sm p-4 rounded-xl transition-all duration-200 outline-none border border-transparent focus:border-[#4d41df] focus:ring-2 focus:ring-[#4d41df]/20 resize-none"
                    ></textarea>
                  </div>

                  {/* Submit Button */}
                  <div className="flex flex-col gap-2 pt-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-[#4d41df] hover:bg-[#675df9] text-white font-semibold text-sm py-3.5 px-6 rounded-full shadow-[0_8px_24px_rgba(77,65,223,0.3)] hover:-translate-y-0.5 active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-2 group cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <span>Sending Message...</span>
                      ) : (
                        <>
                          <span>Send Message</span>
                          <Send className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                        </>
                      )}
                    </button>

                    <div className="flex items-center justify-center gap-1.5 text-[#5f5e64] pt-1">
                      <Lock className="w-3.5 h-3.5 text-[#777587]" />
                      <p className="text-[11px]">Your privacy is respected. No spam or unsolicited emails.</p>
                    </div>
                  </div>
                </form>
              )}
            </div>

            {/* Right Column: Channels & Workspace */}
            <div className="lg:col-span-5 flex flex-col gap-6">
              {/* Workspace Studio Presentation Card */}
              <div className="rounded-3xl overflow-hidden shadow-md bg-white border border-[#eeedf4] relative group">
                <div className="relative h-56 w-full overflow-hidden bg-gradient-to-br from-[#191928] via-[#22213a] to-[#12121f] p-5 flex flex-col justify-between border-b border-white/10">
                  {/* ========================================================================= */}
                  {/* CONTACT STUDIO DESK IMAGE: Replace src="" with your studio or desk photo */}
                  {/* Example: src="/assets/studio-workspace.jpg" */}
                  {/* ========================================================================= */}
                  <img
                    src=""
                    alt="Sailesh Design Studio Desk"
                    className="w-full h-full object-cover absolute inset-0 z-0 transition-transform duration-500 group-hover:scale-105"
                    onError={(e) => {
                      (e.currentTarget as HTMLElement).style.display = 'none';
                    }}
                  />

                  {/* Subtle Grid Background */}
                  <div
                    className="absolute inset-0 opacity-15"
                    style={{
                      backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)',
                      backgroundSize: '18px 18px',
                    }}
                  ></div>

                  <div className="relative z-10 flex items-center justify-between">
                    <div className="bg-white/10 backdrop-blur-md px-3 py-1 rounded-full border border-white/15 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span className="text-xs font-semibold text-white">Sailesh Studio Hub</span>
                    </div>
                    <span className="text-[10px] font-mono text-purple-300 bg-purple-500/20 px-2 py-0.5 rounded border border-purple-500/30">
                      LIVE DESK
                    </span>
                  </div>

                  {/* Studio Metrics Graphic */}
                  <div className="relative z-10 grid grid-cols-3 gap-2 my-auto">
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-2.5 border border-white/10 text-center">
                      <span className="text-lg font-bold text-white block">100%</span>
                      <span className="text-[9px] text-white/60 uppercase">On-Time Delivery</span>
                    </div>
                    <div className="bg-[#4d41df]/40 backdrop-blur-sm rounded-xl p-2.5 border border-[#857dfa]/40 text-center">
                      <span className="text-lg font-bold text-white block">&lt; 24h</span>
                      <span className="text-[9px] text-white/80 uppercase">Response Time</span>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-2.5 border border-white/10 text-center">
                      <span className="text-lg font-bold text-emerald-400 block">Open</span>
                      <span className="text-[9px] text-white/60 uppercase">Client Slots</span>
                    </div>
                  </div>

                  <div className="relative z-10 flex items-center justify-between text-[10px] font-mono text-white/50">
                    <span>Remote Worldwide • Mon-Fri</span>
                    <span className="text-[#a49dfa]">UTC / EST Timezones</span>
                  </div>
                </div>

                <div className="p-6 flex flex-col gap-3 -mt-6 relative">
                  <div className="bg-[#f4f3fa] rounded-2xl p-4 flex flex-col gap-2 border border-[#eeedf4]">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] text-[#777587] uppercase tracking-wider font-semibold">
                        Client Status
                      </span>
                      <span className="inline-flex items-center gap-1.5 bg-emerald-500/10 text-emerald-600 px-2.5 py-0.5 rounded-full text-xs font-semibold">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        Q2 Booking Open
                      </span>
                    </div>
                    <p className="text-sm font-semibold text-[#1a1b20]">
                      Currently accepting select new client projects for Q2.
                    </p>
                    <div className="flex items-center gap-1.5 text-[#5f5e64] text-xs pt-1">
                      <span>Monday – Friday • 9:00 AM – 6:00 PM EST</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Direct Channels Compact Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Email */}
                <a
                  href="mailto:thakorsailes8@gmail.com"
                  className="group bg-white hover:bg-[#f4f3fa] rounded-2xl p-5 shadow-sm border border-[#eeedf4] transition-all duration-200 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-[#e3dfff] flex items-center justify-center text-[#4d41df] group-hover:scale-110 transition-transform">
                      <Mail className="w-5 h-5" />
                    </div>
                    <span className="text-xs text-[#777587]">↗</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-[#777587] uppercase tracking-wider font-semibold block">
                      Official Inquiries
                    </span>
                    <span className="text-xs font-bold text-[#1a1b20] break-all">
                      thakorsailes8@gmail.com
                    </span>
                    <p className="text-xs text-[#4d41df] mt-1 font-semibold">Send an email →</p>
                  </div>
                </a>

                {/* WhatsApp */}
                <a
                  href="https://wa.me/"
                  target="_blank"
                  rel="noreferrer"
                  className="group bg-white hover:bg-[#f4f3fa] rounded-2xl p-5 shadow-sm border border-[#eeedf4] transition-all duration-200 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <span className="text-xs text-[#777587]">↗</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-[#777587] uppercase tracking-wider font-semibold block">
                      Direct Messaging
                    </span>
                    <span className="text-xs font-bold text-[#1a1b20] break-all">
                      +1 (555) 019-2834
                    </span>
                    <p className="text-xs text-emerald-600 mt-1 font-semibold">Quick chat on WhatsApp →</p>
                  </div>
                </a>

                {/* Instagram */}
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noreferrer"
                  className="group bg-white hover:bg-[#f4f3fa] rounded-2xl p-5 shadow-sm border border-[#eeedf4] transition-all duration-200 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-pink-50 text-pink-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Instagram className="w-5 h-5" />
                    </div>
                    <span className="text-xs text-[#777587]">↗</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-[#777587] uppercase tracking-wider font-semibold block">
                      Social Feed
                    </span>
                    <span className="text-xs font-bold text-[#1a1b20] break-all">
                      @sailesh.designs
                    </span>
                    <p className="text-xs text-pink-600 mt-1 font-semibold">Recent updates &amp; reels →</p>
                  </div>
                </a>

                {/* Archive / Portfolio */}
                <a
                  href="#gallery"
                  className="group bg-white hover:bg-[#f4f3fa] rounded-2xl p-5 shadow-sm border border-[#eeedf4] transition-all duration-200 flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-[#eeedf4] text-[#1a1b20] flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Globe className="w-5 h-5" />
                    </div>
                    <span className="text-xs text-[#777587]">↗</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-[#777587] uppercase tracking-wider font-semibold block">
                      Archive &amp; Work
                    </span>
                    <span className="text-xs font-bold text-[#1a1b20] break-all">
                      saileshdesigns.com
                    </span>
                    <p className="text-xs text-[#1a1b20] mt-1 font-semibold">Explore interactive projects →</p>
                  </div>
                </a>
              </div>
            </div>
          </div>

          {/* FAQ Accordion Section */}
          <section className="mt-16 pt-8 border-t border-[#eeedf4]">
            <div className="bg-white rounded-3xl p-6 md:p-10 shadow-sm border border-[#eeedf4]">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-3">
                <div>
                  <span className="text-xs text-[#4d41df] uppercase tracking-widest font-bold">
                    Common Queries
                  </span>
                  <h2 className="text-2xl md:text-3xl font-bold text-[#1a1b20] tracking-tight mt-1">
                    Frequently Asked Questions
                  </h2>
                </div>
                <p className="text-xs sm:text-sm text-[#464555] max-w-sm">
                  Quick answers about onboarding, delivery standards, and collaboration workflow before initiating a proposal.
                </p>
              </div>

              <div className="flex flex-col gap-3">
                {FAQ_LIST.map((faq) => {
                  const isExpanded = expandedFaq === faq.id;
                  return (
                    <div
                      key={faq.id}
                      className="bg-[#f4f3fa] rounded-2xl overflow-hidden transition-all duration-200 border border-[#eeedf4]"
                    >
                      <button
                        onClick={() => toggleFaq(faq.id)}
                        className="w-full flex items-center justify-between p-5 text-left font-semibold text-base text-[#1a1b20] hover:text-[#4d41df] transition-colors cursor-pointer"
                      >
                        <span>{faq.question}</span>
                        <ChevronDown
                          className={`w-5 h-5 text-[#777587] transition-transform duration-200 ${
                            isExpanded ? 'rotate-180 text-[#4d41df]' : ''
                          }`}
                        />
                      </button>
                      {isExpanded && (
                        <div className="px-5 pb-5 animate-fadeIn">
                          <p className="text-sm text-[#464555] leading-relaxed">
                            {faq.answer}
                          </p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
